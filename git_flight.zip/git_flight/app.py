from flask import Flask, request, render_template
import joblib
import numpy as np

app = Flask(__name__)

# Load the trained model
model = joblib.load('/Users/nxshl/Desktop/fight_app/model/model.pkl.py')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get input values from the form
    try:
        safety_score = float(request.form['Safety_Score'])
        days_since_inspection = float(request.form['Days_Since_Inspection'])
        total_safety_complaints = float(request.form['Total_Safety_Complaints'])
        control_metric = float(request.form['Control_Metric'])
        turbulence_in_gforces = float(request.form['Turbulence_In_gforces'])
        cabin_temperature = float(request.form['Cabin_Temperature'])
        accident_type_code = int(request.form['Accident_Type_Code'])
        max_elevation = float(request.form['Max_Elevation'])
        violations = int(request.form['Violations'])
        adverse_weather_metric = float(request.form['Adverse_Weather_Metric'])
        accident_id = int(request.form['Accident_ID'])

        # Create a numpy array for the prediction
        features = np.array([[safety_score, days_since_inspection, total_safety_complaints,
                              control_metric, turbulence_in_gforces, cabin_temperature,
                              accident_type_code, max_elevation, violations, 
                              adverse_weather_metric, accident_id]])
        
        # Get prediction
        prediction = model.predict(features)

        # Assuming the prediction is some kind of classification
        result = f"Predicted result: {prediction[0]}"

    except Exception as e:
        result = f"Error: {str(e)}"

    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
